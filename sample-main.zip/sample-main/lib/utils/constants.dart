const String appLogo = 'assets/logo.png';
const List<Map<String, String>> nowShowingMovies = [
  {
    'title': 'Movie 1',
    'image': 'https://via.placeholder.com/120x180?text=Movie+1',
  },
  {
    'title': 'Movie 2',
    'image': 'https://via.placeholder.com/120x180?text=Movie+2',
  },
  {
    'title': 'Movie 3',
    'image': 'https://via.placeholder.com/120x180?text=Movie+3',
  },
];
