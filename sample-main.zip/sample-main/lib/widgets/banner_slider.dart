import 'package:flutter/material.dart';

class BannerSlider extends StatelessWidget {
  const BannerSlider({super.key});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 180,
      child: PageView(
        children: [
          Image.network('https://via.placeholder.com/350x150?text=Movie+1'),
          Image.network('https://via.placeholder.com/350x150?text=Movie+2'),
          Image.network('https://via.placeholder.com/350x150?text=Movie+3'),
        ],
      ),
    );
  }
}
