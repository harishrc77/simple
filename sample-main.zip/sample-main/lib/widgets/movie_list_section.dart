import 'package:flutter/material.dart';
import 'movie_card.dart';

class MovieListSection extends StatelessWidget {
  final String title;
  final List<Map<String, String>> movies;
  const MovieListSection({
    super.key,
    required this.title,
    required this.movies,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0),
          child: Text(title, style: Theme.of(context).textTheme.titleLarge),
        ),
        SizedBox(
          height: 260,
          child: ListView(
            scrollDirection: Axis.horizontal,
            children: movies
                .map(
                  (movie) =>
                      MovieCard(title: movie['title']!, image: movie['image']!),
                )
                .toList(),
          ),
        ),
      ],
    );
  }
}
