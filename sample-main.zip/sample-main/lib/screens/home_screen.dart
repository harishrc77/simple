import 'package:flutter/material.dart';
import 'dart:async';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  bool showNowShowing = true;
  final PageController _bannerController = PageController();
  int _currentBanner = 0;
  late Timer _bannerTimer;

  final List<String> bannerImages = [
    'assets/inception.jpg',
    'assets/interstellar.jpg',
    'assets/dark_knight.jpg',
    'assets/endgame.jpg',
    'assets/joker.jpg',
  ];

  final List<Map<String, String>> nowShowingMovies = [
    {'title': 'Inception', 'image': 'assets/inception.jpg'},
    {'title': 'Interstellar', 'image': 'assets/interstellar.jpg'},
    {'title': 'The Dark Knight', 'image': 'assets/dark_knight.jpg'},
    {'title': 'Avengers: Endgame', 'image': 'assets/endgame.jpg'},
    {'title': 'Joker', 'image': 'assets/joker.jpg'},
  ];

  final List<Map<String, String>> upcomingMovies = [
    {'title': 'Deadpool & Wolverine', 'image': 'assets/inception.jpg'},
    {'title': 'Mission Impossible 8', 'image': 'assets/interstellar.jpg'},
    {'title': 'Avatar 3', 'image': 'assets/dark_knight.jpg'},
    {'title': 'Fantastic Four', 'image': 'assets/endgame.jpg'},
    {'title': 'Blade', 'image': 'assets/joker.jpg'},
  ];

  @override
  void initState() {
    super.initState();
    _bannerTimer = Timer.periodic(const Duration(seconds: 5), (timer) {
      if (_bannerController.hasClients) {
        _currentBanner = (_currentBanner + 1) % bannerImages.length;
        _bannerController.animateToPage(
          _currentBanner,
          duration: const Duration(milliseconds: 500),
          curve: Curves.easeInOut,
        );
      }
    });
  }

  @override
  void dispose() {
    _bannerTimer.cancel();
    _bannerController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final movies = showNowShowing ? nowShowingMovies : upcomingMovies;
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            Image.asset('assets/logo.png', height: 32),
            const SizedBox(width: 8),
            const Text('Movie Booking'),
            const Spacer(),
            IconButton(icon: const Icon(Icons.search), onPressed: () {}),
          ],
        ),
        backgroundColor: Theme.of(context).colorScheme.primary,
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFF181818), // Slightly lighter black
              Colors.black, // Solid black
            ],
          ),
        ),
        child: ListView(
          children: [
            // Banner section
            SizedBox(
              height: 180,
              child: PageView.builder(
                controller: _bannerController,
                itemCount: bannerImages.length,
                itemBuilder: (context, index) {
                  return Image.asset(bannerImages[index], fit: BoxFit.cover);
                },
              ),
            ),
            const SizedBox(height: 16),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: Row(
                children: [
                  TextButton(
                    onPressed: () {
                      setState(() {
                        showNowShowing = true;
                      });
                    },
                    child: Text(
                      'SHOW NOW SHOWING',
                      style: TextStyle(
                        color: showNowShowing
                            ? Theme.of(context).colorScheme.primary
                            : Colors.grey,
                        fontWeight: showNowShowing
                            ? FontWeight.bold
                            : FontWeight.normal,
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  TextButton(
                    onPressed: () {
                      setState(() {
                        showNowShowing = false;
                      });
                    },
                    child: Text(
                      'SHOW UPCOMING',
                      style: TextStyle(
                        color: !showNowShowing
                            ? Theme.of(context).colorScheme.primary
                            : Colors.grey,
                        fontWeight: !showNowShowing
                            ? FontWeight.bold
                            : FontWeight.normal,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(
                horizontal: 16.0,
                vertical: 8.0,
              ),
              child: Text(
                showNowShowing ? 'Now Showing' : 'Upcoming Movies',
                style: Theme.of(context).textTheme.titleLarge,
              ),
            ),
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              itemCount: movies.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 16,
                crossAxisSpacing: 16,
                childAspectRatio: 0.7,
              ),
              itemBuilder: (context, index) {
                final movie = movies[index];
                return Card(
                  elevation: 3,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Expanded(
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child: Image.asset(
                              movie['image']!,
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                        const SizedBox(height: 10),
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton(
                            onPressed: () {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text(
                                    showNowShowing
                                        ? 'Booking for ${movie['title']}'
                                        : 'Reminder set for ${movie['title']}',
                                  ),
                                ),
                              );
                            },
                            child: Text(
                              showNowShowing ? 'Book Now' : 'Remind Now!',
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
