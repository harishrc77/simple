# Movie Booking App Documentation

## Project Overview
A Flutter mobile application for booking movie tickets, featuring:
- Login with phone and OTP
- Home page with app bar, banner section, and movie sliders
- Movie details and booking flow
- Booking confirmation screen

## Folder Structure
```
lib/
 ┣ main.dart
 ┣ screens/
 ┃ ┣ login_screen.dart
 ┃ ┣ otp_screen.dart
 ┃ ┣ home_screen.dart
 ┃ ┣ movie_detail_screen.dart
 ┃ ┣ booking_screen.dart
 ┃ ┗ success_screen.dart
 ┣ widgets/
 ┃ ┣ banner_slider.dart
 ┃ ┣ movie_card.dart
 ┃ ┣ movie_list_section.dart
 ┃ ┗ search_bar.dart
 ┣ models/
 ┃ ┗ movie.dart
 ┣ services/
 ┃ ┗ auth_service.dart
 ┗ utils/
   ┗ constants.dart
assets/
 ┣ logo.png
 ┣ inception.jpg
 ┣ interstellar.jpg
 ┣ dark_knight.jpg
 ┣ endgame.jpg
 ┗ joker.jpg
```

## pubspec.yaml Assets Section
```
flutter:
  uses-material-design: true
  assets:
    - assets/logo.png
    - assets/inception.jpg
    - assets/interstellar.jpg
    - assets/dark_knight.jpg
    - assets/endgame.jpg
    - assets/joker.jpg
```

## Features Implemented

### 1. Login & OTP
- Phone number input screen (`login_screen.dart`)
- OTP screen with pin fields (`otp_screen.dart`)
- Dummy verification logic in `auth_service.dart`
- On success, navigates to HomeScreen

### 2. Home Screen (`home_screen.dart`)
- App bar with logo and search icon
- Banner carousel (local images)
- Toggle between "SHOW NOW SHOWING" and "SHOW UPCOMING"
- Horizontal slider of movie cards for each section
- "Book Now" button for now showing, "Remind Now!" for upcoming

### 3. Movie Details & Booking
- Placeholder screens for movie details, booking, and success
- Navigation routes set up in `main.dart`

## How to Add/Change Movies
- Add new images to `assets/`
- Update the `nowShowingMovies` and `upcomingMovies` lists in `home_screen.dart`

## How to Run
1. Ensure all images are in the `assets/` folder and declared in `pubspec.yaml`
2. Run `flutter pub get`
3. Run `flutter run` to launch the app

## Next Steps / TODO
- Implement real OTP with Firebase (optional)
- Complete movie detail and booking screens
- Add seat selection, show timings, and booking confirmation
- Polish UI with Google Fonts and custom themes
- Add backend integration for real data (optional)

---

This documentation covers all features and structure implemented so far. Update as you add more features!
